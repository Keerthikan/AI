Digital Counter Simulation
--------------------------

Tutorial

1, Double-click on index.html icon in the Counter Simulation Tutorial folder to view the tutorial in your browser.

2. Click anywhere on the cover page to open the tutorial.

3, When viewing the program listing, click on any of the highlighted line numbers to go to a note associated with that part of the program.

4. Click on the left-turning arrow icon in the left margin of a note to return to the line in the program listing linked to the note.

Program Code

ex_counter.nxc is the NXC source code for the program described in the tutorial. You can compile this file and run the RXE file generated on your NXT.
